package Simple.Warehouse.Project;

public interface WarehouseSpace {
	
	 	boolean isOccupied();
	    char getProductCode();
	    void setProductCode(char productCode);
	    

}
